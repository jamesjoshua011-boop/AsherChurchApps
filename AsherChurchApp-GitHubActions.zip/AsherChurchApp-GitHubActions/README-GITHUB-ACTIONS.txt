ASHER CHURCH APP - GitHub Actions

Important:
This project is configured with a GitHub Actions workflow, but the Android Gradle Wrapper
files (gradlew, gradlew.bat, gradle/wrapper/*) must be present for the workflow to run.

Before pushing:
1. Open the project in Android Studio or another Gradle-capable environment once and generate
   the Gradle wrapper with:
       gradle wrapper --gradle-version 8.7
2. Commit gradlew, gradlew.bat and gradle/wrapper/*.
3. Push the project to GitHub.
4. Open Actions -> Build Asher APK -> Run workflow.
5. After the job finishes, open the workflow run and download the "Asher-debug-apk" artifact.
