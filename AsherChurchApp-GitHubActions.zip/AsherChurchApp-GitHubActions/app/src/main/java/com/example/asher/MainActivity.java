package com.example.asher;

import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, body; TextView pageTitle, content; String currentUser="Asher Member";
 int purple=Color.rgb(79,70,229);

 public void onCreate(Bundle b){super.onCreate(b); showLogin();}

 void showLogin(){setContentView(R.layout.activity_main);
  EditText e=findViewById(R.id.email),p=findViewById(R.id.password); Button l=findViewById(R.id.login); TextView s=findViewById(R.id.status);
  l.setOnClickListener(v->{if(e.getText().length()>0&&p.getText().length()>0){currentUser=e.getText().toString();showApp();}else s.setText("Please enter email and password.");});
 }
 TextView tv(String t,int size){TextView x=new TextView(this);x.setText(t);x.setTextSize(size);x.setPadding(0,8,0,8);return x;}
 Button nav(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);return b;}

 void showApp(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  LinearLayout top=new LinearLayout(this);top.setPadding(20,16,20,8);top.setGravity(Gravity.CENTER_VERTICAL);
  pageTitle=tv("Asher",25);pageTitle.setTextColor(purple);pageTitle.setTypeface(null,Typeface.BOLD);top.addView(pageTitle,new LinearLayout.LayoutParams(0,-2,1));
  Button bell=nav("🔔");top.addView(bell,new LinearLayout.LayoutParams(70,60));bell.setOnClickListener(v->showNotifications());
  root.addView(top); body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(20,10,20,10);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);String[] ns={"Home","Shifts","Duties","Profile"};
  for(String n:ns){Button b=nav(n);bar.addView(b,new LinearLayout.LayoutParams(0,65,1));b.setOnClickListener(v->showPage(n));}
  root.addView(bar);setContentView(root);showPage("Home");
 }
 void clear(String title){body.removeAllViews();pageTitle.setText(title);}
 void showPage(String p){
  clear(p);
  if(p.equals("Home")){body.addView(tv("Welcome, "+currentUser,21));body.addView(tv("NEXT SHIFT",14));body.addView(tv("Sunday • 27 Sep 2026\n07:30 – Main Entrance\nRole: Welcome & seating",18));body.addView(tv("SERVICE CHECKLIST\n✓ Arrive 30 minutes early\n✓ Check entrance\n✓ Prepare seating\n✓ Coordinate with leader",17));}
  if(p.equals("Shifts")){body.addView(tv("MY SHIFT SCHEDULE",16));body.addView(tv("27 Sep 2026 • 07:30\nMain Entrance\nAssigned: You\n\n04 Oct 2026 • 08:00\nSanctuary\nAssigned: You\n\n11 Oct 2026 • 07:30\nMain Entrance\nAssigned: You",18));}
  if(p.equals("Duties")){body.addView(tv("ASHER DUTIES",16));body.addView(tv("• Welcome members and visitors\n• Guide seating\n• Keep order during service\n• Prepare the Lord's Table\n• Assist with offerings\n• Report issues to the Asher leader",18));}
  if(p.equals("Profile")){body.addView(tv("MY PROFILE",16));body.addView(tv("Name: "+currentUser+"\nRole: Asher\nStatus: Active",18));Button out=nav("Log out");body.addView(out);out.setOnClickListener(v->showLogin());}
 }
 void showNotifications(){clear("Notifications");body.addView(tv("🔔 REMINDERS",16));body.addView(tv("Your next shift is Sunday at 07:30.\nPlease arrive at least 30 minutes early.\n\nLeader reminder: Check the entrance and seating before service.",18));}
}